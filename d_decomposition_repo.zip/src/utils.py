import matplotlib.pyplot as plt
import numpy as np

def show_comparison_grid(images_list, labels, sample_ids):
    rows = len(images_list)
    cols = len(sample_ids)
    fig, axes = plt.subplots(rows, cols, figsize=(3.5 * cols, 4.2 * rows))
    for i in range(rows):
        for j in range(cols):
            ax = axes[i, j] if rows > 1 else axes[j]
            ax.imshow(images_list[i][sample_ids[j]].reshape(64, 64), cmap='gray')
            ax.axis('off')
            if j == 0:
                ax.annotate(labels[i], xy=(0, 0.5), xytext=(-50, 32),
                            textcoords='offset points', ha='right', va='center',
                            fontsize=14, fontweight='bold', rotation=0)
    plt.suptitle("Face Reconstruction Comparison Across Methods", fontsize=18, y=0.92)
    plt.tight_layout(rect=[0.03, 0.03, 1, 0.93])
    plt.show()