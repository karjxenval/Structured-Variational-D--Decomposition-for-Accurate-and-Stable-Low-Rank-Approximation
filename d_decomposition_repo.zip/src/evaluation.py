import numpy as np
from sklearn.metrics import mean_squared_error

def compute_rmse(true, recon, mask):
    return np.sqrt(mean_squared_error(true[mask], recon[mask]))

def compute_frobenius_error(true, recon):
    return np.linalg.norm(true - recon, 'fro')