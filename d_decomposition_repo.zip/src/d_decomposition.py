import numpy as np

def d_decomposition_rect(A, k, alpha1=1e-3, alpha2=1e-3, alpha3=1e-3, epsilon=1e-4, Tmax=100):
    n, m = A.shape
    P = np.random.randn(n, k)
    Q = np.random.randn(k, m)
    delta_prev = np.inf

    for t in range(Tmax):
        PtP = P.T @ P
        QQT = Q @ Q.T
        D = np.linalg.pinv(PtP + 1e-6 * np.eye(k)) @ P.T @ A @ Q.T @ np.linalg.pinv(QQT + alpha2 * np.eye(k))
        R = D @ Q @ Q.T @ D.T + alpha1 * np.eye(k)
        P = A @ Q.T @ D.T @ np.linalg.pinv(R + 1e-6 * np.eye(k))
        S = D.T @ P.T @ P @ D + alpha3 * np.eye(k)
        Q = np.linalg.pinv(S + 1e-6 * np.eye(k)) @ D.T @ P.T @ A
        A_hat = P @ D @ Q
        delta = np.linalg.norm(A - A_hat, 'fro')
        if abs(delta - delta_prev) < epsilon:
            break
        delta_prev = delta

    return P, D, Q, A_hat, delta