# D-Decomposition for Low-Rank Matrix Approximation

This repository implements the D-Decomposition framework proposed in the manuscript:
Structured Variational D-Decomposition for Accurate and Stable Low-Rank Approximation

## Features
- Alternating minimization algorithm for matrix factorization of the form A ≈ P D Q
- Regularized low-rank approximation with conditioning control
- Evaluation and benchmarking on the Olivetti Faces dataset
- Comparison against Truncated SVD with RMSE and Frobenius error
- Visual reconstruction grid and runtime analysis

## Structure
- `src/` contains the core decomposition algorithm and evaluation tools
- `notebook/` includes an interactive Jupyter demo and figures
- `requirements.txt` specifies dependencies

## Usage
pip install -r requirements.txt

Then open the notebook:

jupyter notebook notebook/demo_d_decomposition.ipynb

## License
MIT